import numpy as np
import scipy.fft as fft
import scipy.signal.windows as window
import scipy.signal as scisig
from scipy.sparse.linalg import spsolve
import scipy.stats as scistats
import statistics
from typing import Optional, Tuple, List, Union


import numpy as np
from scipy import fft, signal
from typing import Optional, Tuple